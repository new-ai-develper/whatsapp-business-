# WhatsApp Business API Management Platform

## Overview

This is a self-hosted SaaS platform for managing WhatsApp Business API operations. The application provides a complete messaging dashboard with features for sending and receiving messages, managing contacts, creating templates, setting up automation, team management, and analytics.

## System Architecture

The application follows a full-stack architecture with a React frontend and Express.js backend:

- **Frontend**: React with TypeScript, using shadcn/ui components and Tailwind CSS
- **Backend**: Express.js with TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **Authentication**: Replit Auth (OIDC-based)
- **Deployment**: Vite for development and production builds

## Key Components

### Frontend Architecture
- **React Router**: Using wouter for client-side routing
- **State Management**: TanStack Query for server state management
- **UI Components**: shadcn/ui component library with Radix UI primitives
- **Styling**: Tailwind CSS with custom WhatsApp-themed colors
- **Forms**: React Hook Form with Zod validation

### Backend Architecture
- **API Layer**: RESTful Express.js server with TypeScript
- **Database Layer**: Drizzle ORM with PostgreSQL
- **Authentication**: Replit Auth with session management
- **File Structure**: Modular route handlers and storage abstraction

### Database Schema
The application uses the following main entities:
- **Users**: User profiles with role-based access (admin, manager, agent)
- **Contacts**: WhatsApp contact management
- **Conversations**: Chat conversations with contacts
- **Messages**: Individual messages within conversations
- **Templates**: WhatsApp message templates
- **Automations**: Auto-reply and workflow configurations
- **Sessions**: User session storage for authentication

## Data Flow

1. **Authentication Flow**: Users authenticate via Replit Auth, sessions stored in PostgreSQL
2. **Message Flow**: Messages sent through API endpoints, stored in database, real-time updates via polling
3. **Contact Management**: CRUD operations for contacts with phone number validation
4. **Template System**: Pre-configured message templates for bulk messaging
5. **Automation Engine**: Rule-based auto-replies and workflow triggers

## External Dependencies

- **Database**: Neon serverless PostgreSQL database
- **Authentication**: Replit OIDC authentication service
- **UI Framework**: Radix UI primitives for accessible components
- **Validation**: Zod for schema validation
- **Charts**: Recharts for analytics visualization

## Deployment Strategy

The application is configured for deployment on Replit with the following setup:
- **Development**: Vite dev server with hot reload
- **Production**: Built static assets served by Express
- **Database**: Environment-based connection to PostgreSQL
- **Sessions**: Database-backed session storage
- **Static Assets**: Served from dist/public directory

## Changelog

```
Changelog:
- June 30, 2025. Initial setup
```

## User Preferences

```
Preferred communication style: Simple, everyday language.
```