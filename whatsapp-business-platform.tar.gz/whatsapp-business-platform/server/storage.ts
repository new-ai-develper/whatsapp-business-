import {
  users,
  contacts,
  messages,
  conversations,
  templates,
  automations,
  type User,
  type UpsertUser,
  type Contact,
  type InsertContact,
  type Message,
  type InsertMessage,
  type Template,
  type InsertTemplate,
  type Automation,
  type InsertAutomation,
  type Conversation,
} from "@shared/schema";

export interface IStorage {
  // User operations (required for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Contact operations
  getContacts(userId: string): Promise<Contact[]>;
  getContact(id: number): Promise<Contact | undefined>;
  createContact(contact: InsertContact): Promise<Contact>;
  updateContact(id: number, contact: Partial<InsertContact>): Promise<Contact>;
  deleteContact(id: number): Promise<void>;
  
  // Message operations
  getMessages(conversationId: number): Promise<Message[]>;
  createMessage(message: InsertMessage): Promise<Message>;
  updateMessageStatus(id: number, status: string): Promise<Message>;
  
  // Conversation operations
  getConversations(userId: string): Promise<Conversation[]>;
  getConversation(id: number): Promise<Conversation | undefined>;
  createConversation(contactId: number): Promise<Conversation>;
  updateConversation(id: number, data: Partial<Conversation>): Promise<Conversation>;
  
  // Template operations
  getTemplates(userId: string): Promise<Template[]>;
  createTemplate(template: InsertTemplate): Promise<Template>;
  updateTemplate(id: number, template: Partial<InsertTemplate>): Promise<Template>;
  deleteTemplate(id: number): Promise<void>;
  
  // Automation operations
  getAutomations(userId: string): Promise<Automation[]>;
  createAutomation(automation: InsertAutomation): Promise<Automation>;
  updateAutomation(id: number, automation: Partial<InsertAutomation>): Promise<Automation>;
  deleteAutomation(id: number): Promise<void>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User> = new Map();
  private contacts: Map<number, Contact> = new Map();
  private messages: Map<number, Message> = new Map();
  private conversations: Map<number, Conversation> = new Map();
  private templates: Map<number, Template> = new Map();
  private automations: Map<number, Automation> = new Map();
  
  private contactId = 1;
  private messageId = 1;
  private conversationId = 1;
  private templateId = 1;
  private automationId = 1;

  // User operations
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const existingUser = this.users.get(userData.id);
    const user: User = {
      ...userData,
      createdAt: existingUser?.createdAt || new Date(),
      updatedAt: new Date(),
    };
    this.users.set(userData.id, user);
    return user;
  }

  // Contact operations
  async getContacts(userId: string): Promise<Contact[]> {
    return Array.from(this.contacts.values()).filter(c => c.userId === userId);
  }

  async getContact(id: number): Promise<Contact | undefined> {
    return this.contacts.get(id);
  }

  async createContact(contactData: InsertContact): Promise<Contact> {
    const contact: Contact = {
      ...contactData,
      id: this.contactId++,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.contacts.set(contact.id, contact);
    return contact;
  }

  async updateContact(id: number, contactData: Partial<InsertContact>): Promise<Contact> {
    const existing = this.contacts.get(id);
    if (!existing) throw new Error("Contact not found");
    
    const updated: Contact = {
      ...existing,
      ...contactData,
      updatedAt: new Date(),
    };
    this.contacts.set(id, updated);
    return updated;
  }

  async deleteContact(id: number): Promise<void> {
    this.contacts.delete(id);
  }

  // Message operations
  async getMessages(conversationId: number): Promise<Message[]> {
    return Array.from(this.messages.values())
      .filter(m => m.conversationId === conversationId)
      .sort((a, b) => a.createdAt!.getTime() - b.createdAt!.getTime());
  }

  async createMessage(messageData: InsertMessage): Promise<Message> {
    const message: Message = {
      ...messageData,
      id: this.messageId++,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.messages.set(message.id, message);
    return message;
  }

  async updateMessageStatus(id: number, status: string): Promise<Message> {
    const existing = this.messages.get(id);
    if (!existing) throw new Error("Message not found");
    
    const updated: Message = {
      ...existing,
      status: status as any,
      updatedAt: new Date(),
    };
    this.messages.set(id, updated);
    return updated;
  }

  // Conversation operations
  async getConversations(userId: string): Promise<Conversation[]> {
    const userContacts = await this.getContacts(userId);
    const contactIds = userContacts.map(c => c.id);
    
    return Array.from(this.conversations.values())
      .filter(c => contactIds.includes(c.contactId))
      .sort((a, b) => b.lastActivity!.getTime() - a.lastActivity!.getTime());
  }

  async getConversation(id: number): Promise<Conversation | undefined> {
    return this.conversations.get(id);
  }

  async createConversation(contactId: number): Promise<Conversation> {
    const conversation: Conversation = {
      id: this.conversationId++,
      contactId,
      lastMessageId: null,
      lastActivity: new Date(),
      unreadCount: 0,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.conversations.set(conversation.id, conversation);
    return conversation;
  }

  async updateConversation(id: number, data: Partial<Conversation>): Promise<Conversation> {
    const existing = this.conversations.get(id);
    if (!existing) throw new Error("Conversation not found");
    
    const updated: Conversation = {
      ...existing,
      ...data,
      updatedAt: new Date(),
    };
    this.conversations.set(id, updated);
    return updated;
  }

  // Template operations
  async getTemplates(userId: string): Promise<Template[]> {
    return Array.from(this.templates.values()).filter(t => t.userId === userId);
  }

  async createTemplate(templateData: InsertTemplate): Promise<Template> {
    const template: Template = {
      ...templateData,
      id: this.templateId++,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.templates.set(template.id, template);
    return template;
  }

  async updateTemplate(id: number, templateData: Partial<InsertTemplate>): Promise<Template> {
    const existing = this.templates.get(id);
    if (!existing) throw new Error("Template not found");
    
    const updated: Template = {
      ...existing,
      ...templateData,
      updatedAt: new Date(),
    };
    this.templates.set(id, updated);
    return updated;
  }

  async deleteTemplate(id: number): Promise<void> {
    this.templates.delete(id);
  }

  // Automation operations
  async getAutomations(userId: string): Promise<Automation[]> {
    return Array.from(this.automations.values()).filter(a => a.userId === userId);
  }

  async createAutomation(automationData: InsertAutomation): Promise<Automation> {
    const automation: Automation = {
      ...automationData,
      id: this.automationId++,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.automations.set(automation.id, automation);
    return automation;
  }

  async updateAutomation(id: number, automationData: Partial<InsertAutomation>): Promise<Automation> {
    const existing = this.automations.get(id);
    if (!existing) throw new Error("Automation not found");
    
    const updated: Automation = {
      ...existing,
      ...automationData,
      updatedAt: new Date(),
    };
    this.automations.set(id, updated);
    return updated;
  }

  async deleteAutomation(id: number): Promise<void> {
    this.automations.delete(id);
  }
}

export const storage = new MemStorage();
