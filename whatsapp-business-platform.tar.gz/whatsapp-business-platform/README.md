# WhatsApp Business API Management Platform

A self-hosted SaaS platform for managing WhatsApp Business API operations with comprehensive messaging, contact management, templates, automation, and analytics features.

## Features

- **Dashboard**: Real-time messaging statistics and quick actions
- **Messaging**: Send/receive messages with conversation management
- **Contact Management**: Full CRUD operations for WhatsApp contacts
- **Templates**: Create and manage reusable message templates
- **Automation**: Auto-replies, keyword triggers, and workflow automation
- **Team Management**: Role-based access control (Admin, Manager, Agent)
- **Analytics**: Performance dashboards with charts and metrics
- **Responsive Design**: Works on desktop and mobile devices

## Technology Stack

- **Frontend**: React + TypeScript + Tailwind CSS + shadcn/ui
- **Backend**: Express.js + TypeScript
- **Database**: PostgreSQL with Drizzle ORM (or in-memory for development)
- **Authentication**: Replit Auth (OIDC-based)
- **Charts**: Recharts for analytics visualization

## Quick Start

### Prerequisites

- Node.js 18+ 
- PostgreSQL database (optional - uses in-memory storage by default)

### Installation

1. Extract the zip file and navigate to the project directory:
```bash
cd whatsapp-business-platform
```

2. Install dependencies:
```bash
npm install
```

3. Set up environment variables:
```bash
cp .env.example .env
```

Edit `.env` with your configuration:
```env
# Required for Replit Auth (if using)
REPLIT_DOMAINS=your-domain.com
REPL_ID=your-repl-id
SESSION_SECRET=your-session-secret

# Optional: PostgreSQL database
DATABASE_URL=postgresql://user:pass@localhost:5432/whatsapp_db
```

4. Start the development server:
```bash
npm run dev
```

The application will be available at `http://localhost:5000`

## Self-Hosting Setup

### Option 1: Docker Deployment (Recommended)

1. Build and run with Docker:
```bash
docker build -t whatsapp-platform .
docker run -p 5000:5000 --env-file .env whatsapp-platform
```

### Option 2: VPS Deployment

1. Upload files to your VPS
2. Install Node.js and PostgreSQL
3. Set up environment variables
4. Install dependencies and build:
```bash
npm install
npm run build
```
5. Start with PM2:
```bash
npm install -g pm2
pm2 start npm --name "whatsapp-platform" -- start
```

### Option 3: Development Mode (No Database)

The platform includes in-memory storage for quick testing:
```bash
npm run dev
```

## Configuration

### Authentication Setup

For production, configure Replit Auth or implement your preferred authentication:

1. **Replit Auth**: Set `REPLIT_DOMAINS` and `REPL_ID`
2. **Custom Auth**: Modify `server/replitAuth.ts`

### Database Setup

1. **PostgreSQL**: Set `DATABASE_URL` in environment
2. **In-Memory**: Leave `DATABASE_URL` unset (development only)

### WhatsApp API Integration

To connect real WhatsApp Business API:

1. Obtain WhatsApp Business API credentials
2. Update `server/routes.ts` to integrate with WhatsApp API
3. Replace mock message sending with actual API calls

## File Structure

```
├── client/                 # React frontend
│   ├── src/
│   │   ├── components/     # UI components
│   │   ├── pages/          # Page components
│   │   ├── hooks/          # React hooks
│   │   └── lib/            # Utilities
├── server/                 # Express backend
│   ├── index.ts            # Server entry point
│   ├── routes.ts           # API routes
│   ├── storage.ts          # Data storage layer
│   └── replitAuth.ts       # Authentication
├── shared/                 # Shared schemas
└── README.md              # This file
```

## API Endpoints

### Authentication
- `GET /api/auth/user` - Get current user
- `GET /api/login` - Initiate login
- `GET /api/logout` - Logout

### Contacts
- `GET /api/contacts` - List contacts
- `POST /api/contacts` - Create contact
- `PUT /api/contacts/:id` - Update contact
- `DELETE /api/contacts/:id` - Delete contact

### Messages
- `GET /api/conversations` - List conversations
- `GET /api/conversations/:id/messages` - Get messages
- `POST /api/conversations/:id/messages` - Send message

### Templates
- `GET /api/templates` - List templates
- `POST /api/templates` - Create template
- `PUT /api/templates/:id` - Update template
- `DELETE /api/templates/:id` - Delete template

### Automations
- `GET /api/automations` - List automations
- `POST /api/automations` - Create automation
- `PUT /api/automations/:id` - Update automation
- `DELETE /api/automations/:id` - Delete automation

### Analytics
- `GET /api/analytics/stats` - Get dashboard statistics

## Customization

### UI Themes
- Modify `client/src/index.css` for color schemes
- Update WhatsApp green: `--whatsapp: hsl(142, 70%, 45%)`

### Adding Features
1. Add new schema to `shared/schema.ts`
2. Update storage interface in `server/storage.ts`
3. Add API routes in `server/routes.ts`
4. Create frontend components and pages

### WhatsApp Integration
Replace mock API calls in `server/routes.ts` with actual WhatsApp Business API:
- Message sending
- Webhook handling
- Media upload/download
- Template management

## Deployment Considerations

### Security
- Use HTTPS in production
- Set secure session cookies
- Implement rate limiting
- Validate all user inputs

### Performance
- Enable database connection pooling
- Use Redis for session storage
- Implement caching for frequently accessed data
- Optimize database queries

### Monitoring
- Add logging with Winston or similar
- Set up error tracking (Sentry)
- Monitor database performance
- Track API response times

## Support

For issues and questions:
1. Check the documentation
2. Review the code comments
3. Test with mock data first
4. Verify environment configuration

## License

This project is provided as-is for self-hosting purposes.