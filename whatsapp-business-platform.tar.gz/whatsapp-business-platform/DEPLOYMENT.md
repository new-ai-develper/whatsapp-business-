# Deployment Guide

## Quick Start Options

### Option 1: Docker (Recommended)
```bash
# Clone/extract the project
cd whatsapp-business-platform

# Copy environment file
cp .env.example .env

# Edit .env with your settings
nano .env

# Start with Docker Compose
docker-compose up -d

# Access at http://localhost:5000
```

### Option 2: VPS Deployment
```bash
# On your VPS
git clone <your-repo> whatsapp-platform
cd whatsapp-platform

# Install Node.js 18+
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# Install dependencies
npm install

# Set up environment
cp .env.example .env
nano .env

# Build and start
npm run build
npm start

# Or use PM2 for production
npm install -g pm2
pm2 start npm --name "whatsapp" -- start
pm2 save
pm2 startup
```

### Option 3: Development Mode
```bash
# For testing without database
npm install
npm run dev

# Access at http://localhost:5000
```

## Environment Configuration

Required variables:
```env
SESSION_SECRET=your-super-secret-key-here
REPLIT_DOMAINS=your-domain.com
REPL_ID=your-repl-id
```

Optional (for database):
```env
DATABASE_URL=postgresql://user:pass@host:5432/db
```

## Domain Setup

1. Point your domain to server IP
2. Update REPLIT_DOMAINS in .env
3. Configure SSL with Let's Encrypt:
```bash
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d your-domain.com
```

## Database Setup

### PostgreSQL
```bash
sudo apt install postgresql
sudo -u postgres createdb whatsapp_db
sudo -u postgres createuser whatsapp_user
sudo -u postgres psql -c "ALTER USER whatsapp_user WITH PASSWORD 'secure_password';"
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE whatsapp_db TO whatsapp_user;"
```

Run init.sql:
```bash
psql -U whatsapp_user -d whatsapp_db -f init.sql
```

## Security Checklist

- [ ] Change default SESSION_SECRET
- [ ] Use HTTPS in production
- [ ] Set up firewall (ufw enable)
- [ ] Regular security updates
- [ ] Monitor logs
- [ ] Backup database regularly

## Performance Optimization

1. Enable Nginx caching
2. Use Redis for sessions
3. Database connection pooling
4. Monitor with htop/pm2 monit

## Troubleshooting

### Common Issues

**Port already in use:**
```bash
sudo lsof -i :5000
sudo kill -9 <PID>
```

**Database connection failed:**
- Check DATABASE_URL format
- Verify PostgreSQL is running
- Check firewall settings

**Authentication not working:**
- Verify REPLIT_DOMAINS matches your domain
- Check REPL_ID is correct
- Ensure SESSION_SECRET is set

### Logs
```bash
# PM2 logs
pm2 logs whatsapp

# Docker logs
docker-compose logs app

# System logs
journalctl -u your-service
```

## Backup & Recovery

### Database Backup
```bash
pg_dump -U whatsapp_user whatsapp_db > backup.sql
```

### Restore
```bash
psql -U whatsapp_user whatsapp_db < backup.sql
```

## Monitoring

Set up basic monitoring:
```bash
# Install htop
sudo apt install htop

# Monitor with PM2
pm2 monit

# Check disk space
df -h
```

## Scaling

For high traffic:
1. Use load balancer (Nginx upstream)
2. Database read replicas
3. Redis clustering
4. CDN for static assets
5. Container orchestration (Kubernetes)