import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "wouter";
import { Check, CheckCheck, Eye } from "lucide-react";

interface RecentMessagesProps {
  conversations: any[];
  isLoading: boolean;
}

export function RecentMessages({ conversations, isLoading }: RecentMessagesProps) {
  const getStatusIcon = (status: string) => {
    switch (status) {
      case "delivered":
        return <CheckCheck className="w-3 h-3 mr-1" />;
      case "read":
        return <Eye className="w-3 h-3 mr-1" />;
      default:
        return <Check className="w-3 h-3 mr-1" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "delivered":
        return "bg-green-100 text-green-800";
      case "read":
        return "bg-blue-100 text-blue-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const formatTimeAgo = (date: string) => {
    const now = new Date();
    const messageDate = new Date(date);
    const diffInMinutes = Math.floor((now.getTime() - messageDate.getTime()) / (1000 * 60));
    
    if (diffInMinutes < 1) return "now";
    if (diffInMinutes < 60) return `${diffInMinutes}m ago`;
    if (diffInMinutes < 1440) return `${Math.floor(diffInMinutes / 60)}h ago`;
    return `${Math.floor(diffInMinutes / 1440)}d ago`;
  };

  return (
    <Card className="shadow-sm border border-gray-100">
      <CardHeader>
        <CardTitle className="text-lg font-semibold text-gray-900">Recent Messages</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {isLoading ? (
            Array.from({ length: 3 }).map((_, i) => (
              <div key={i} className="flex items-start space-x-3 p-3 animate-pulse">
                <Skeleton className="w-10 h-10 rounded-full" />
                <div className="flex-1 space-y-2">
                  <div className="flex justify-between">
                    <Skeleton className="h-4 w-24" />
                    <Skeleton className="h-3 w-12" />
                  </div>
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-4 w-16" />
                </div>
              </div>
            ))
          ) : conversations.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              <p>No recent conversations</p>
            </div>
          ) : (
            conversations.slice(0, 3).map((conversation) => (
              <div
                key={conversation.id}
                className="flex items-start space-x-3 p-3 hover:bg-gray-50 rounded-lg cursor-pointer"
              >
                <Avatar>
                  <AvatarImage src={conversation.contact?.profileImageUrl} />
                  <AvatarFallback>
                    {conversation.contact?.name?.charAt(0) || "U"}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <p className="text-sm font-medium text-gray-900 truncate">
                      {conversation.contact?.name || "Unknown Contact"}
                    </p>
                    <span className="text-xs text-gray-500">
                      {conversation.lastActivity ? formatTimeAgo(conversation.lastActivity) : ""}
                    </span>
                  </div>
                  <p className="text-sm text-gray-600 truncate">
                    {conversation.contact?.phone || "No recent message"}
                  </p>
                  <div className="flex items-center mt-1">
                    <Badge
                      variant="secondary"
                      className={`inline-flex items-center px-2 py-1 rounded-full text-xs ${getStatusColor("delivered")}`}
                    >
                      {getStatusIcon("delivered")}
                      Delivered
                    </Badge>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
        <Link href="/messages">
          <Button 
            variant="ghost" 
            className="w-full mt-4 text-center whatsapp-text hover:text-[#1E8E4F] font-medium text-sm py-2"
          >
            View All Messages
          </Button>
        </Link>
      </CardContent>
    </Card>
  );
}
