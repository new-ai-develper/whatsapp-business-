import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ComposeModal } from "@/components/common/compose-modal";
import { useToast } from "@/hooks/use-toast";
import { Edit, FilePlus, UserPlus, Zap } from "lucide-react";
import { Link } from "wouter";

export function QuickActions() {
  const [isComposeOpen, setIsComposeOpen] = useState(false);
  const { toast } = useToast();

  const handleCreateTemplate = () => {
    toast({
      title: "Redirecting",
      description: "Opening template creator...",
    });
  };

  const handleAddContact = () => {
    toast({
      title: "Redirecting", 
      description: "Opening contact form...",
    });
  };

  const activeAutomations = [
    {
      name: "Welcome Message",
      description: "Auto-reply for new contacts",
      isActive: true,
      color: "bg-green-500",
    },
    {
      name: "Order Updates",
      description: "Keyword: #order",
      isActive: true,
      color: "bg-blue-500",
    },
    {
      name: "Support Hours",
      description: "Outside business hours",
      isActive: false,
      color: "bg-gray-400",
    },
  ];

  return (
    <div className="space-y-6">
      {/* Quick Actions */}
      <Card className="shadow-sm border border-gray-100">
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-gray-900">Quick Actions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <Button
              onClick={() => setIsComposeOpen(true)}
              className="w-full flex items-center justify-center px-4 py-3 whatsapp-green text-white hover:bg-[#1E8E4F] transition-colors"
            >
              <Edit className="w-4 h-4 mr-2" />
              Compose Message
            </Button>
            
            <Link href="/templates">
              <Button
                onClick={handleCreateTemplate}
                className="w-full flex items-center justify-center px-4 py-3 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors"
              >
                <FilePlus className="w-4 h-4 mr-2" />
                Create Template
              </Button>
            </Link>
            
            <Link href="/contacts">
              <Button
                onClick={handleAddContact}
                className="w-full flex items-center justify-center px-4 py-3 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors"
              >
                <UserPlus className="w-4 h-4 mr-2" />
                Add Contact
              </Button>
            </Link>
          </div>
        </CardContent>
      </Card>

      {/* Active Automations */}
      <Card className="shadow-sm border border-gray-100">
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-gray-900">Active Automations</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {activeAutomations.map((automation, index) => (
              <div
                key={index}
                className={`flex items-center justify-between p-3 rounded-lg ${
                  automation.isActive ? "bg-green-50" : "bg-gray-50"
                }`}
              >
                <div>
                  <p className="text-sm font-medium text-gray-900">{automation.name}</p>
                  <p className="text-xs text-gray-600">{automation.description}</p>
                </div>
                <span className={`w-3 h-3 rounded-full ${automation.color}`}></span>
              </div>
            ))}
          </div>
          <Link href="/automation">
            <Button
              variant="ghost"
              className="w-full mt-4 text-center whatsapp-text hover:text-[#1E8E4F] font-medium text-sm py-2"
            >
              <Zap className="w-4 h-4 mr-2" />
              Manage Automations
            </Button>
          </Link>
        </CardContent>
      </Card>

      <ComposeModal 
        isOpen={isComposeOpen} 
        onClose={() => setIsComposeOpen(false)} 
      />
    </div>
  );
}
