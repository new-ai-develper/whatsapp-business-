import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Send, CheckCheck, Users, MessageCircle } from "lucide-react";

interface StatsGridProps {
  stats: any;
  isLoading: boolean;
}

export function StatsGrid({ stats, isLoading }: StatsGridProps) {
  if (isLoading) {
    return (
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {Array.from({ length: 4 }).map((_, i) => (
          <Card key={i} className="animate-pulse">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div className="space-y-2 flex-1">
                  <Skeleton className="h-4 w-20" />
                  <Skeleton className="h-8 w-16" />
                  <Skeleton className="h-3 w-24" />
                </div>
                <Skeleton className="w-12 h-12 rounded-lg" />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  const statItems = [
    {
      title: "Messages Sent",
      value: stats?.messagesSent || 0,
      change: "+12% from last week",
      changeType: "positive",
      icon: Send,
      iconBg: "bg-blue-100",
      iconColor: "text-blue-600",
    },
    {
      title: "Delivered",
      value: stats?.delivered || 0,
      change: `${stats?.deliveryRate || 0}% rate`,
      changeType: "positive",
      icon: CheckCheck,
      iconBg: "bg-green-100",
      iconColor: "text-green-600",
    },
    {
      title: "Active Contacts",
      value: stats?.activeContacts || 0,
      change: "+8 today",
      changeType: "positive",
      icon: Users,
      iconBg: "bg-purple-100",
      iconColor: "text-purple-600",
    },
    {
      title: "Response Rate",
      value: `${stats?.responseRate || 0}%`,
      change: "+5% from last week",
      changeType: "positive",
      icon: MessageCircle,
      iconBg: "bg-orange-100",
      iconColor: "text-orange-600",
    },
  ];

  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
      {statItems.map((item, index) => (
        <Card key={index} className="shadow-sm border border-gray-100">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">{item.title}</p>
                <p className="text-2xl font-bold text-gray-900">{item.value}</p>
                <p className={`text-xs ${
                  item.changeType === "positive" ? "text-green-600" : "text-red-600"
                }`}>
                  {item.change}
                </p>
              </div>
              <div className={`w-12 h-12 ${item.iconBg} rounded-lg flex items-center justify-center`}>
                <item.icon className={`h-6 w-6 ${item.iconColor}`} />
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
