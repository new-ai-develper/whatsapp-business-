import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Search, Edit } from "lucide-react";
import { cn } from "@/lib/utils";

interface ConversationListProps {
  conversations: any[];
  isLoading: boolean;
  selectedConversationId: number | null;
  onSelectConversation: (id: number) => void;
}

export function ConversationList({
  conversations,
  isLoading,
  selectedConversationId,
  onSelectConversation,
}: ConversationListProps) {
  const [searchTerm, setSearchTerm] = useState("");

  const filteredConversations = conversations.filter((conversation) =>
    conversation.contact?.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <>
      <div className="p-4 border-b border-gray-200">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-gray-900">Conversations</h3>
          <Button variant="ghost" size="sm" className="text-gray-400 hover:text-gray-600">
            <Edit className="h-4 w-4" />
          </Button>
        </div>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <Input
            placeholder="Search conversations..."
            className="pl-10"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>

      <div className="overflow-y-auto h-full">
        {isLoading ? (
          Array.from({ length: 5 }).map((_, i) => (
            <div key={i} className="p-4 border-b border-gray-100 animate-pulse">
              <div className="flex items-start space-x-3">
                <div className="w-12 h-12 bg-gray-200 rounded-full"></div>
                <div className="flex-1">
                  <div className="h-4 bg-gray-200 rounded mb-2"></div>
                  <div className="h-3 bg-gray-200 rounded w-3/4"></div>
                </div>
              </div>
            </div>
          ))
        ) : filteredConversations.length === 0 ? (
          <div className="p-8 text-center text-gray-500">
            <p>No conversations found</p>
          </div>
        ) : (
          filteredConversations.map((conversation) => (
            <div
              key={conversation.id}
              className={cn(
                "p-4 border-b border-gray-100 hover:bg-gray-50 cursor-pointer",
                selectedConversationId === conversation.id && "bg-blue-50 border-blue-200"
              )}
              onClick={() => onSelectConversation(conversation.id)}
            >
              <div className="flex items-start space-x-3">
                <Avatar>
                  <AvatarImage src={conversation.contact?.profileImageUrl} />
                  <AvatarFallback>
                    {conversation.contact?.name?.charAt(0) || "U"}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <p className="text-sm font-medium text-gray-900 truncate">
                      {conversation.contact?.name}
                    </p>
                    <span className="text-xs text-gray-500">
                      {conversation.lastActivity
                        ? new Date(conversation.lastActivity).toLocaleTimeString([], {
                            hour: "2-digit",
                            minute: "2-digit",
                          })
                        : ""}
                    </span>
                  </div>
                  <p className="text-sm text-gray-600 truncate">
                    {conversation.contact?.phone}
                  </p>
                  <div className="flex items-center justify-between mt-1">
                    <Badge
                      variant={
                        conversation.contact?.status === "online"
                          ? "default"
                          : conversation.contact?.status === "away"
                          ? "secondary"
                          : "outline"
                      }
                      className={cn(
                        "text-xs",
                        conversation.contact?.status === "online" &&
                          "bg-green-100 text-green-800",
                        conversation.contact?.status === "away" &&
                          "bg-yellow-100 text-yellow-800",
                        conversation.contact?.status === "offline" &&
                          "bg-gray-100 text-gray-800"
                      )}
                    >
                      <span
                        className={cn(
                          "w-2 h-2 rounded-full mr-1",
                          conversation.contact?.status === "online" && "bg-green-500",
                          conversation.contact?.status === "away" && "bg-yellow-500",
                          conversation.contact?.status === "offline" && "bg-gray-400"
                        )}
                      ></span>
                      {conversation.contact?.status || "offline"}
                    </Badge>
                    {conversation.unreadCount > 0 && (
                      <Badge className="bg-[#25D366] text-white">
                        {conversation.unreadCount}
                      </Badge>
                    )}
                  </div>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </>
  );
}
