import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Phone, Video, MoreVertical, Send, Paperclip, Smile, CheckCheck } from "lucide-react";

interface ChatInterfaceProps {
  conversationId: number | null;
  conversations: any[];
}

export function ChatInterface({ conversationId, conversations }: ChatInterfaceProps) {
  const [messageText, setMessageText] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const selectedConversation = conversations.find(c => c.id === conversationId);
  const contact = selectedConversation?.contact;

  const { data: messages, isLoading: messagesLoading } = useQuery({
    queryKey: ["/api/conversations", conversationId, "messages"],
    enabled: !!conversationId,
  });

  const sendMessageMutation = useMutation({
    mutationFn: async (data: { content: string }) => {
      return await apiRequest("POST", `/api/conversations/${conversationId}/messages`, {
        content: data.content,
        messageType: "text",
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/conversations", conversationId, "messages"] });
      queryClient.invalidateQueries({ queryKey: ["/api/conversations"] });
      setMessageText("");
      toast({
        title: "Message sent",
        description: "Your message has been sent successfully",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to send message",
        variant: "destructive",
      });
    },
  });

  const handleSendMessage = () => {
    if (!messageText.trim() || !conversationId) return;
    sendMessageMutation.mutate({ content: messageText.trim() });
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  if (!conversationId) {
    return (
      <div className="flex items-center justify-center h-full bg-gray-50">
        <div className="text-center">
          <MessageSquare className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">Select a conversation</h3>
          <p className="text-gray-500">Choose a conversation from the list to start messaging</p>
        </div>
      </div>
    );
  }

  return (
    <>
      {/* Chat Header */}
      <div className="p-4 border-b border-gray-200 bg-white">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Avatar>
              <AvatarImage src={contact?.profileImageUrl} />
              <AvatarFallback>
                {contact?.name?.charAt(0) || "U"}
              </AvatarFallback>
            </Avatar>
            <div>
              <h4 className="text-sm font-medium text-gray-900">{contact?.name}</h4>
              <p className="text-xs flex items-center">
                <span
                  className={`w-2 h-2 rounded-full mr-1 ${
                    contact?.status === "online"
                      ? "bg-green-500"
                      : contact?.status === "away"
                      ? "bg-yellow-500"
                      : "bg-gray-400"
                  }`}
                ></span>
                <span className={
                  contact?.status === "online"
                    ? "text-green-600"
                    : contact?.status === "away"
                    ? "text-yellow-600"
                    : "text-gray-600"
                }>
                  {contact?.status || "offline"}
                </span>
              </p>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <Button variant="ghost" size="sm" className="text-gray-400 hover:text-gray-600">
              <Phone className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="sm" className="text-gray-400 hover:text-gray-600">
              <Video className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="sm" className="text-gray-400 hover:text-gray-600">
              <MoreVertical className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 bg-gray-50">
        {messagesLoading ? (
          <div className="space-y-4">
            {Array.from({ length: 3 }).map((_, i) => (
              <div key={i} className="flex animate-pulse">
                <div className="w-8 h-8 bg-gray-200 rounded-full mr-2"></div>
                <div className="bg-gray-200 rounded-lg p-3 max-w-xs h-16"></div>
              </div>
            ))}
          </div>
        ) : (
          <div className="space-y-4">
            {messages?.map((message: any) => (
              <div
                key={message.id}
                className={`flex ${message.isIncoming ? "items-start" : "items-start justify-end"}`}
              >
                {message.isIncoming && (
                  <Avatar className="w-8 h-8 mr-2">
                    <AvatarImage src={contact?.profileImageUrl} />
                    <AvatarFallback className="text-xs">
                      {contact?.name?.charAt(0) || "U"}
                    </AvatarFallback>
                  </Avatar>
                )}
                <div
                  className={`rounded-lg p-3 max-w-xs ${
                    message.isIncoming
                      ? "bg-white shadow-sm"
                      : "bg-[#25D366] text-white"
                  }`}
                >
                  <p className="text-sm">{message.content}</p>
                  <div className={`flex items-center justify-end mt-1 ${
                    message.isIncoming ? "text-gray-500" : "text-white/75"
                  }`}>
                    <span className="text-xs mr-2">
                      {new Date(message.createdAt).toLocaleTimeString([], {
                        hour: "2-digit",
                        minute: "2-digit",
                      })}
                    </span>
                    {!message.isIncoming && (
                      <CheckCheck className="w-3 h-3" />
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Message Input */}
      <div className="p-4 bg-white border-t border-gray-200">
        <div className="flex items-end space-x-2">
          <Button variant="ghost" size="sm" className="text-gray-400 hover:text-gray-600">
            <Paperclip className="h-4 w-4" />
          </Button>
          <div className="flex-1">
            <Textarea
              value={messageText}
              onChange={(e) => setMessageText(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Type a message..."
              className="min-h-[40px] resize-none"
              rows={1}
            />
          </div>
          <Button variant="ghost" size="sm" className="text-gray-400 hover:text-gray-600">
            <Smile className="h-4 w-4" />
          </Button>
          <Button
            onClick={handleSendMessage}
            disabled={!messageText.trim() || sendMessageMutation.isPending}
            className="whatsapp-green text-white"
            size="sm"
          >
            <Send className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </>
  );
}
