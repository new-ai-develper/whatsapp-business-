import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { ConversationList } from "@/components/messages/conversation-list";
import { ChatInterface } from "@/components/messages/chat-interface";
import { useState } from "react";

export default function Messages() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();
  const [selectedConversationId, setSelectedConversationId] = useState<number | null>(null);

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: conversations, isLoading: conversationsLoading } = useQuery({
    queryKey: ["/api/conversations"],
    enabled: isAuthenticated,
  });

  if (isLoading || !isAuthenticated) {
    return <div>Loading...</div>;
  }

  return (
    <div className="h-screen flex flex-col">
      <div className="flex-1 flex">
        {/* Conversations List */}
        <div className="w-full lg:w-1/3 bg-white border-r border-gray-200">
          <ConversationList
            conversations={conversations || []}
            isLoading={conversationsLoading}
            selectedConversationId={selectedConversationId}
            onSelectConversation={setSelectedConversationId}
          />
        </div>

        {/* Chat Interface */}
        <div className="hidden lg:flex lg:flex-col lg:flex-1">
          <ChatInterface
            conversationId={selectedConversationId}
            conversations={conversations || []}
          />
        </div>
      </div>
    </div>
  );
}
