import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { MessageSquare, Shield, Users, Zap } from "lucide-react";

export default function Landing() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50 flex items-center justify-center p-4">
      <div className="max-w-4xl w-full">
        <div className="text-center mb-8">
          <div className="flex items-center justify-center mb-4">
            <div className="w-16 h-16 bg-[#25D366] rounded-2xl flex items-center justify-center">
              <MessageSquare className="w-8 h-8 text-white" />
            </div>
          </div>
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            WhatsB Management
          </h1>
          <p className="text-lg text-gray-600 mb-8">
            Self-hosted WhatsApp Business API management platform
          </p>
          
          <Button 
            size="lg" 
            className="whatsapp-green text-white px-8 py-3 text-lg font-semibold"
            onClick={() => window.location.href = '/api/login'}
          >
            Get Started
          </Button>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mt-12">
          <Card className="text-center">
            <CardHeader>
              <MessageSquare className="w-8 h-8 mx-auto text-[#25D366] mb-2" />
              <CardTitle className="text-lg">Messaging</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600">
                Send and receive WhatsApp messages with templates and media support
              </p>
            </CardContent>
          </Card>

          <Card className="text-center">
            <CardHeader>
              <Users className="w-8 h-8 mx-auto text-[#25D366] mb-2" />
              <CardTitle className="text-lg">Team Management</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600">
                Multi-user system with role-based access control
              </p>
            </CardContent>
          </Card>

          <Card className="text-center">
            <CardHeader>
              <Zap className="w-8 h-8 mx-auto text-[#25D366] mb-2" />
              <CardTitle className="text-lg">Automation</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600">
                Auto-replies, workflows, and intelligent message routing
              </p>
            </CardContent>
          </Card>

          <Card className="text-center">
            <CardHeader>
              <Shield className="w-8 h-8 mx-auto text-[#25D366] mb-2" />
              <CardTitle className="text-lg">Self-Hosted</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600">
                Complete control over your messaging infrastructure
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
