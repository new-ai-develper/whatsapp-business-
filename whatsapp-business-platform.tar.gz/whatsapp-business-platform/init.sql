-- Database initialization script for WhatsApp Business Platform
-- This script creates the necessary tables for the application

-- Create sessions table (required for authentication)
CREATE TABLE IF NOT EXISTS sessions (
    sid VARCHAR NOT NULL COLLATE "default" PRIMARY KEY,
    sess JSON NOT NULL,
    expire TIMESTAMP(6) NOT NULL
);

CREATE INDEX IF NOT EXISTS "IDX_session_expire" ON sessions (expire);

-- Create users table
CREATE TABLE IF NOT EXISTS users (
    id VARCHAR PRIMARY KEY NOT NULL,
    email VARCHAR UNIQUE,
    first_name VARCHAR,
    last_name VARCHAR,
    profile_image_url VARCHAR,
    role VARCHAR DEFAULT 'agent' CHECK (role IN ('admin', 'manager', 'agent')),
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Create contacts table
CREATE TABLE IF NOT EXISTS contacts (
    id SERIAL PRIMARY KEY,
    user_id VARCHAR NOT NULL,
    name VARCHAR NOT NULL,
    phone VARCHAR NOT NULL UNIQUE,
    email VARCHAR,
    profile_image_url VARCHAR,
    status VARCHAR DEFAULT 'offline' CHECK (status IN ('online', 'offline', 'away')),
    last_seen TIMESTAMP,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Create conversations table
CREATE TABLE IF NOT EXISTS conversations (
    id SERIAL PRIMARY KEY,
    contact_id INTEGER NOT NULL,
    last_message_id INTEGER,
    last_activity TIMESTAMP DEFAULT NOW(),
    unread_count INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Create messages table
CREATE TABLE IF NOT EXISTS messages (
    id SERIAL PRIMARY KEY,
    conversation_id INTEGER NOT NULL,
    sender_id VARCHAR,
    content TEXT NOT NULL,
    message_type VARCHAR NOT NULL CHECK (message_type IN ('text', 'image', 'document', 'audio', 'video', 'template')),
    status VARCHAR DEFAULT 'sent' CHECK (status IN ('sent', 'delivered', 'read', 'failed')),
    is_incoming BOOLEAN DEFAULT false,
    metadata JSONB,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Create templates table
CREATE TABLE IF NOT EXISTS templates (
    id SERIAL PRIMARY KEY,
    user_id VARCHAR NOT NULL,
    name VARCHAR NOT NULL,
    content TEXT NOT NULL,
    category VARCHAR NOT NULL,
    variables JSONB,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Create automations table
CREATE TABLE IF NOT EXISTS automations (
    id SERIAL PRIMARY KEY,
    user_id VARCHAR NOT NULL,
    name VARCHAR NOT NULL,
    trigger VARCHAR NOT NULL CHECK (trigger IN ('keyword', 'new_contact', 'schedule', 'webhook')),
    trigger_value TEXT,
    action VARCHAR NOT NULL CHECK (action IN ('send_message', 'assign_agent', 'add_tag')),
    action_data JSONB,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_contacts_user_id ON contacts(user_id);
CREATE INDEX IF NOT EXISTS idx_conversations_contact_id ON conversations(contact_id);
CREATE INDEX IF NOT EXISTS idx_messages_conversation_id ON messages(conversation_id);
CREATE INDEX IF NOT EXISTS idx_templates_user_id ON templates(user_id);
CREATE INDEX IF NOT EXISTS idx_automations_user_id ON automations(user_id);

-- Insert sample data (optional - remove for production)
-- Sample admin user
INSERT INTO users (id, email, first_name, last_name, role) 
VALUES ('admin-001', 'admin@whatsapp-platform.com', 'Admin', 'User', 'admin')
ON CONFLICT (id) DO NOTHING;

-- Sample templates
INSERT INTO templates (user_id, name, content, category, variables) VALUES
('admin-001', 'Welcome Message', 'Hello {{name}}! Welcome to our service. How can we help you today?', 'greeting', '{"name": "string"}'),
('admin-001', 'Order Confirmation', 'Your order #{{order_id}} has been confirmed. Total: ${{amount}}. Estimated delivery: {{delivery_date}}.', 'order', '{"order_id": "string", "amount": "number", "delivery_date": "date"}'),
('admin-001', 'Support Hours', 'Thank you for contacting us. Our support hours are 9 AM - 6 PM, Monday to Friday. We will respond to your message during business hours.', 'support', '{}')
ON CONFLICT DO NOTHING;

-- Sample automations
INSERT INTO automations (user_id, name, trigger, trigger_value, action, action_data) VALUES
('admin-001', 'Welcome Auto-Reply', 'keyword', 'hello,hi,start', 'send_message', '{"template_id": 1}'),
('admin-001', 'Business Hours', 'schedule', '0 18 * * 1-5', 'send_message', '{"template_id": 3}'),
('admin-001', 'Order Status', 'keyword', 'order,status,track', 'send_message', '{"message": "Please provide your order number and we will check the status for you."}')